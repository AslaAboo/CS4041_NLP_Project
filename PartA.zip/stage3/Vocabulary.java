
import java.io.*;
import java.util.*;

public class Vocabulary
{
    public static void main(String[] args) throws FileNotFoundException, Exception
        {
        Scanner scanner = new Scanner(new File("data.txt")).useDelimiter("[^a-zA-Z]+");
        String fileOutput = "vocabulary.txt";
        String charset = "UTF-8";
        PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(fileOutput), charset));
        Map<String, Integer> map = new HashMap<String, Integer>();
        while (scanner.hasNext())
            {
            String word = scanner.next();
            if (map.containsKey(word))
                {
                map.put(word, map.get(word)+1);
                }
            else
                {
                map.put(word, 1);
                }
            }

        List<Map.Entry<String, Integer>> entries = new ArrayList<Map.Entry<String,Integer>>( map.entrySet());

        Collections.sort(entries, new Comparator<Map.Entry<String, Integer>>() {

            @Override
            public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
                return b.getKey().compareTo(a.getKey());
            }
        });

        
        for(int i = 0; i < map.size(); i++){
//            System.out.println(entries.get(entries.size() - i - 1).getKey()+" "+entries.get(entries.size() - i - 1).getValue());
            if(entries.get(entries.size() - i - 1).getValue() > 1)
            {
               	writer.println(entries.get(entries.size() - i - 1).getKey());
            }
        }
        scanner.close();
        writer.close();
        System.out.println("Created a text file named \"vocabulary.txt\" containing set of all words in the corpus which appears at least 2 times.");
        }
}
	