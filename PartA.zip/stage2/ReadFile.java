import java.io.DataInputStream;
import java.io.FileInputStream;
import java.util.Arrays;
import java.io.*;
import java.lang.*;
import java.util.*;

public class ReadFile{
	
	public static void main (String args[]) {
		
		
	try{
		
	        
		 DataInputStream stopwords = 
		    new DataInputStream (
		    	 new FileInputStream ("stopwords.txt"));
		 byte[] datainBytes = new byte[stopwords.available()];
		 stopwords.readFully(datainBytes);
		 stopwords.close();
		       
		 String content = new String(datainBytes, 0, datainBytes.length);
	
		 String data[] = content.split("\\s+"); 

//		 System.out.println(Arrays.toString(data));
//		 System.out.println(data.length);
			 
		 File file = new File("data.txt");
			
		File temp =  File.createTempFile("data", ".txt", file.getParentFile());

		String charset = "UTF-8";

		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), charset));

		PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(temp), charset));

			for (String line; (line = reader.readLine()) != null;)
			{
				
    			String[] s1 = line.split("\\W+");
				for(int i=0; i<s1.length; i++)
				{
					
		//			s1[i] = s1[i].replaceAll("[^a-zA-Z]+", "");
					line = line.replace(s1[i], s1[i].toLowerCase());
		//			line = line.replace(s1[i], s1[i].replaceAll("[^a-zA-Z]+", ""));
					line = line.replaceAll("[/,.()]+", " ");
					line = line.replaceAll("[^-|+|a-zA-Z|\\s]", "");
					
					s1[i] = s1[i].toLowerCase();
				
					for(int j=0; j<data.length; j++)
					{
						if(s1[i].equals(data[j]))
						{
		//					System.out.println(s1[i]);
							line = line.replace(" " + s1[i] + " ", " ");
		//					s1[i] = "";
							break;
						}
					}	
				}
				
	//			System.out.println(line);
				writer.println(line);
				
			}	
			
			reader.close();
			writer.close();
			file.delete();
			temp.renameTo(file);
			System.out.println("Successfully removed stopwords and converted whole text to lowercase.");
	}
				
	catch(Exception e)
	{
		System.err.println("cannot read file");
	}
	
  }
}

