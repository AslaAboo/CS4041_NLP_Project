import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class MNBtraining {
	
	 public static void main(String[] args) throws FileNotFoundException, Exception
     {
		 Scanner scanner = new Scanner(new File("vocabulary.txt")).useDelimiter("[^a-zA-Z]+");
	       
		 // vocabulary count
		 int voc_count = 0;
		 while (scanner.hasNext())
         {
			 String word = scanner.next();
			 voc_count++;
         }
    
//		 System.out.println(voc_count);
		 
		 File file = new File("data.txt");
		 String charset = "UTF-8";
			
		 BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), charset));
		 
		 String fileOutput1 = "pos.txt";
		 String fileOutput2 = "neg.txt";
		   
	     PrintWriter writer1 = new PrintWriter(new OutputStreamWriter(new FileOutputStream(fileOutput1), charset));
	     PrintWriter writer2 = new PrintWriter(new OutputStreamWriter(new FileOutputStream(fileOutput2), charset));
		       
		 // calculating priors
		 
		 int pos_count = 0, neg_count = 0;
		 int pos_words_count = 0, neg_words_count = 0, N = 0;
		 for (String line; (line = reader.readLine()) != null;)
		 {
			 String[] s = line.split("\\s+");
			 switch(s[0])
			 {
			 case "+": {
				 		pos_count++; 
			 			pos_words_count += s.length - 1;
			 			writer1.println(line);
			 			break;
			 		   }
			 case "-": {
				 		neg_count++;
				 		neg_words_count += s.length - 1;
				 		writer2.println(line);
			 			break;
			 		   }
			 }
			 
			 N++;
		 }
		 
		 writer1.close();
		 writer2.close();
		 System.out.println("(+) No. of positive reviews in the training set:	" + pos_count);
		 System.out.println("(-) No. of negative reviews in the training set:	" + neg_count);
//	     System.out.println(pos_words_count);
//		 System.out.println(neg_words_count);
//		 System.out.println(N);
		 double priors[] = new double[2];
		 priors[0] = (double)pos_count/N;
		 priors[1] = (double)neg_count/N;
		 System.out.println("Prior probability, P(+):	" + priors[0]);
		 System.out.println("Prior probability, P(-):	" + priors[1]);
		 
		 //calculating conditional probabilities
		 
		 Scanner scanner1 = new Scanner(new File("pos.txt")).useDelimiter("[^a-zA-Z]+");
		 Scanner scanner2 = new Scanner(new File("neg.txt")).useDelimiter("[^a-zA-Z]+");
	       
		 Map<String, Integer> map1 = new HashMap<String, Integer>();
	        while (scanner1.hasNext())
	            {
	            String word = scanner1.next();
	            if (map1.containsKey(word))
	                {
	                map1.put(word, map1.get(word)+1);
	                }
	            else
	                {
	                map1.put(word, 1);
	                }
	            }

	        List<Map.Entry<String, Integer>> entries1 = new ArrayList<Map.Entry<String,Integer>>( map1.entrySet());

	        writer1 = new PrintWriter(new OutputStreamWriter(new FileOutputStream("model.txt"), charset));
		    
	        double cond_prob;
	        int word_count;
	        for(int i = 0; i < map1.size(); i++){
	//          System.out.println(entries1.get(entries1.size() - i - 1).getKey()+" "+entries1.get(entries1.size() - i - 1).getValue());
	            word_count = entries1.get(entries1.size() - i - 1).getValue();
	            if(entries1.get(entries1.size() - i - 1).getValue() > 1)
	            {
	            	cond_prob = (double)(word_count + 1)/(pos_words_count + voc_count);
	               	writer1.println("+ " + entries1.get(entries1.size() - i - 1).getKey() + " " + cond_prob);
	            }
	        }
	        
	        
	        Map<String, Integer> map2 = new HashMap<String, Integer>();
	        while (scanner2.hasNext())
	            {
	            String word = scanner2.next();
	            if (map2.containsKey(word))
	                {
	                map2.put(word, map2.get(word)+1);
	                }
	            else
	                {
	                map2.put(word, 1);
	                }
	            }

	        List<Map.Entry<String, Integer>> entries2 = new ArrayList<Map.Entry<String,Integer>>( map2.entrySet());

	        for(int i = 0; i < map2.size(); i++){
	  //        System.out.println(entries2.get(entries2.size() - i - 1).getKey()+" "+entries2.get(entries2.size() - i - 1).getValue());
	            word_count = entries2.get(entries2.size() - i - 1).getValue();
		           
	            if(entries2.get(entries2.size() - i - 1).getValue() > 1)
	            {
	            	cond_prob = (double)(word_count + 1)/(neg_words_count + voc_count);
	               	writer1.println("- " + entries2.get(entries2.size() - i - 1).getKey() + " " + cond_prob);
	            }
	        }
	        scanner1.close();
	        scanner2.close();
	        writer1.close();
	        System.out.println();
	        System.out.println("Trained and saved a multinomial naive bayes model in \"model.txt\".");
     }
}
